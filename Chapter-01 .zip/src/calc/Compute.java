package calc;

public class Compute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//declartion of variable
		int a,b,c;
		
		//assign data
		a =33;
		b =55;
		
		//operation 
		c = a*b;
		
		//print /show 
		System.out.println("mul of two numbers "+c);
		

		//add
		c =a+b;
		System.out.println("output is "+c);

	}

}
