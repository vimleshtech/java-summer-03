package calc;

public class HelloWorld 
{

	//[] : array 
	
	int x;
	static int y;
	
	public static void main(String[] arg)
	{
	
		HelloWorld o1 = new HelloWorld();
		o1.x =1;
		o1.y = 1;
		
		HelloWorld o2 = new HelloWorld();
		o2.x =1;
		o2.y = 2;
		
		System.out.println(o1.x);// 1  1 
		System.out.println(o1.y);// 1  2
		System.out.println(o2.x);// 1  1
		System.out.println(o2.y);// 2  2 
		
		
		System.out.println("hi , this is my first code");
		
	}
}
